
===========
Quick start
===========

.. meta::
   :description: Quickstart guide
   :keywords: ptba, pytba, pyTelegramBotAPI, quickstart, guide

Synchronous TeleBot
-------------------
.. literalinclude:: ../../examples/echo_bot.py
    :language: python

Asynchronous TeleBot
--------------------
.. literalinclude:: ../../examples/asynchronous_telebot/echo_bot.py
    :language: python


