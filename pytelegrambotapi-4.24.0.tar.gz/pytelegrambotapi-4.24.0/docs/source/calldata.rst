
=====================
Callback data factory
=====================

.. meta::
   :description: Callback data factory in pyTelegramBotAPI
   :keywords: ptba, pytba, pyTelegramBotAPI, callbackdatafactory, guide, callbackdata, factory


callback\_data file
-----------------------------

.. automodule:: telebot.callback_data
   :members:
   :undoc-members:
   :show-inheritance: