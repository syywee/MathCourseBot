==================
Formatting options
==================

.. meta::
   :description: Formatting options in pyTelegramBotAPI
   :keywords: html, markdown, parse_mode, formatting, ptba, pytba, pyTelegramBotAPI

.. automodule:: telebot.formatting
   :members:
   :undoc-members:
   :show-inheritance:
